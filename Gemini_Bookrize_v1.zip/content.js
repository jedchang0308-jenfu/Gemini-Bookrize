
// State to track current items to avoid unnecessary re-renders
let currentPrompts = [];
let currentTitle = "";

// Debounce utility
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ---------------------------------------------------------
// 1. Feature: Sync Title
// ---------------------------------------------------------
// ---------------------------------------------------------
// 1. Feature: Sync Title
// ---------------------------------------------------------
function syncTitle() {
    try {
        let newTitle = "Gemini";

        // Strategy 1: Check if the document title itself has changed (Gemini sometimes updates it)
        if (document.title && document.title !== "Gemini" && document.title !== "Google Gemini") {
            // Often it is "Title - Gemini", let's use that if available
        }

        // Strategy 2: Look for the specific "conversation-title" test id or role
        // Common in recent variations: button with aria-expanded (menu trigger) at the top
        const possibleTitles = document.querySelectorAll(
            'button[data-test-id="conversation-title"], ' +
            'h1[data-test-id="conversation-title"], ' +
            '[data-testid="conversation-title"], ' +
            'button[aria-label="Rename conversation"], ' +     // The pencil/rename button often lives next to title
            '.conversation-title'
        );

        // Strategy 3: Search top bar for the biggest text that isn't "Gemini" or model name
        const topBar = document.querySelector('header') || document.querySelector('hello-header') || document.querySelector('[role="banner"]');

        if (possibleTitles.length > 0) {
            // If we found specific title elements
            const el = possibleTitles[0];
            // If it's a button, it might be the rename button itself or container
            newTitle = el.innerText || el.textContent;
        } else if (topBar) {
            // Heuristic: iterate through text nodes in the top bar
            // Exclude generic terms
            const bannedTerms = ["Gemini", "Advanced", "Plus", "Pro", "Ultra", "Chat", "Model", "Help", "Settings", "Activity"];

            // Helper to check if node text is a valid title
            const isValid = (t) => {
                t = t.trim();
                return t.length > 2 && !bannedTerms.includes(t) && !t.includes("Upgrade");
            };

            // Try to find a span or div with significant text
            const candidates = Array.from(topBar.querySelectorAll('h1, h2, span, div, button'));
            for (const c of candidates) {
                // Check if visible
                if (c.offsetParent === null) continue;

                const text = c.innerText;
                if (isValid(text)) {
                    // Check looking for "chevron" or "dropdown" which indicates it's the title menu
                    // This is a weak signal but might help differentiate from "Try Gemini Advanced" buttons
                    newTitle = text;
                    break;
                }
            }
        }

        // Cleanup
        newTitle = newTitle.replace(/[\n\r]+/g, ' ').trim();
        // Remove "Rename" or "Edit" if caught
        newTitle = newTitle.replace(/^Rename\s+/i, '');

        // Final check: If we found "對話" (Conversation default), try to see if sidebar has a selected item
        if (newTitle === "對話" || newTitle === "Gemini" || newTitle.includes("Gemini")) {
            const sidebarActive = document.querySelector('[role="navigation"] [aria-selected="true"]');
            if (sidebarActive) {
                const sidebarText = sidebarActive.innerText.split('\n')[0].trim();
                if (sidebarText && sidebarText.length > 2) {
                    newTitle = sidebarText;
                }
            }
        }

        // Apply
        if (newTitle && newTitle.length > 1 && newTitle !== "Gemini" && newTitle !== currentTitle) {
            document.title = newTitle;
            currentTitle = newTitle;
            // console.log("[GeminiNav] Title synced to:", newTitle);
        }
    } catch (e) {
        // Silent fail
    }
}

// ---------------------------------------------------------
// 2. Feature: Conversation Index (Sidebar)
// ---------------------------------------------------------
function updateSidebar() {
    const sidebarId = 'gemini-chat-navigator-sidebar';
    let sidebar = document.getElementById(sidebarId);

    // Create sidebar if not exists
    if (!sidebar) {
        sidebar = document.createElement('div');
        sidebar.id = sidebarId;
        sidebar.innerHTML = `<h3>Conversation Index</h3><div id="gemini-nav-list"></div>`;
        document.body.appendChild(sidebar);
    }

    const listContainer = sidebar.querySelector('#gemini-nav-list');

    // Find user prompts
    // Strategy: Look for the "Edit prompt" button or icon which is unique to user messages.
    // We look for any button with aria-label="Edit prompt" or similar, then find its container's text.
    // Alternatively, user messages in Gemini often have `data-test-id="user-message"` or specific classes.
    // Let's try a robust approach:
    // Find all message blocks. Usually distinct by class.
    // Then check if it is a user message.

    // Attempt 1: Search for 'Edit' buttons which appear on user messages (Pencil icon)
    // This is a very strong signal for "User Message" in Gemini.
    const editButtons = Array.from(document.querySelectorAll('button[aria-label="Edit prompt"], button[aria-label="Edit"], [data-test-id="edit-prompt-button"]'));

    const prompts = [];

    if (editButtons.length > 0) {
        editButtons.forEach((btn, index) => {
            // Traverse up to find the main message container. 
            // We look for a block element that contains the text.
            // Usually, the button is in a footer/toolbar. The text is above it.

            let container = btn.parentElement;
            let text = "";

            // Traverse up max 5 levels to find meaningful text
            for (let i = 0; i < 5; i++) {
                if (!container) break;

                // Heuristic: Get text content of this container, excluding the button's own label
                // Clone to avoid modifying DOM
                const clone = container.cloneNode(true);
                // Remove buttons from clone to get clean text
                const buttons = clone.querySelectorAll('button');
                buttons.forEach(b => b.remove());

                const candidateText = clone.innerText.trim();

                if (candidateText.length > 5 && candidateText.length < 500) { // arbitrary sanity limits
                    text = candidateText;
                    // Identify the closest distinct "message block" for scrolling
                    // If we found text here, this container (or its parent) is likely the message block.
                    break;
                }
                container = container.parentElement;
            }

            if (text) {
                // Deduplicate: Gemini sometimes renders hidden duplicates or mobile/desktop versions
                const isDuplicate = prompts.some(p => p.text === text);
                if (!isDuplicate) {
                    prompts.push({ text: text, element: container, id: index });
                }
            }
        });
    } else {
        // Fallback: search for elements with user-specific attributes if 'Edit' buttons aren't found/labeled
        // Try looking for 'message-content' where the author might be user. 
        // This is hard without specific classes.
        // We will leave the list empty rather than showing garbage.
        console.log("[GeminiNav] No prompts found via Edit buttons.");
    }

    // Render the list
    // Diffing logic to avoid full re-render flickering
    if (JSON.stringify(prompts.map(p => p.text)) !== JSON.stringify(currentPrompts.map(p => p.text))) {
        currentPrompts = prompts;
        listContainer.innerHTML = '';

        if (prompts.length === 0) {
            listContainer.innerHTML = '<div style="padding:10px; opacity:0.6; font-size:12px;">Waiting for messages...<br>(Ensure you are in a chat)</div>';
        }

        prompts.forEach((prompt, idx) => {
            const item = document.createElement('a');
            item.className = 'gemini-nav-item';
            item.title = prompt.text;
            item.innerText = `${idx + 1}. ${prompt.text.substring(0, 35)}${prompt.text.length > 35 ? '...' : ''}`;

            item.onclick = (e) => {
                e.preventDefault();
                prompt.element.scrollIntoView({ behavior: 'smooth', block: 'center' });

                // Highlight active
                document.querySelectorAll('.gemini-nav-item').forEach(el => el.classList.remove('active'));
                item.classList.add('active');
            };

            listContainer.appendChild(item);
        });
    }
}

// ---------------------------------------------------------
// Initialization & Observer
// ---------------------------------------------------------

const run = debounce(() => {
    syncTitle();
    updateSidebar();
}, 500);

// Observer for SPA changes
const observer = new MutationObserver(() => {
    run();
});

// Start observing
observer.observe(document.body, { childList: true, subtree: true });

// Initial run
setTimeout(run, 1000); // Wait for initial load
console.log("Gemini Chat Navigator Loaded");

